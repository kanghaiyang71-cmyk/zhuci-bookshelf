package com.zhuci.bookshelf

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val paper = Color.rgb(248, 245, 237)
    private val ink = Color.rgb(42, 43, 40)
    private val muted = Color.rgb(126, 126, 116)
    private val accent = Color.rgb(82, 127, 128)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = paper
        window.navigationBarColor = paper
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContentView(buildHome())
    }

    private fun buildHome(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(18))
            setBackgroundColor(paper)
        }
        val header = TextView(this).apply {
            text = "逐词书架\n在阅读中，成为更好的自己"
            setTextColor(ink); textSize = 25f; typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(dp(5).toFloat(), 1f)
        }
        root.addView(header)
        val banner = TextView(this).apply {
            text = "每一本书，都是一次新的远航\n\n让英语阅读变得更简单"
            textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(accent, 20)
        }
        val bannerParams = LinearLayout.LayoutParams(-1, dp(132)); bannerParams.topMargin = dp(24)
        root.addView(banner, bannerParams)
        root.addView(label("继续阅读", 20, ink, true).also { it.setPadding(0, dp(28), 0, dp(12)) })
        val book = TextView(this).apply {
            text = "逐词阅读器\n\n内置英汉音标词典 · 离线阅读内核\n\n进入阅读器  ›"
            textSize = 16f; setTextColor(ink); setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.WHITE, 18)
        }
        book.setOnClickListener { openReader() }
        root.addView(book, LinearLayout.LayoutParams(-1, dp(150)))
        root.addView(label("我的书架", 20, ink, true).also { it.setPadding(0, dp(28), 0, dp(12)) })
        val info = TextView(this).apply {
            text = "本地书籍与阅读进度\n\n当前阶段：Android 原生外壳搭建中\n阅读内核：已随应用打包，支持离线加载"
            textSize = 14f; setTextColor(muted); setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.WHITE, 18)
        }
        root.addView(info)
        val spacer = View(this); root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val button = Button(this).apply {
            text = "打开逐词阅读器"; textSize = 16f; isAllCaps = false
            setTextColor(Color.WHITE); background = rounded(accent, 16)
            setOnClickListener { openReader() }
        }
        root.addView(button, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(label("完全离线 · 本地运行 · 词典与音标", 12, muted, false).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0)
        })
        return root
    }

    private fun openReader() { startActivity(Intent(this, ReaderActivity::class.java)) }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
