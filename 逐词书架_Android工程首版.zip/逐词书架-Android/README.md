# 逐词书架 Android

Android 原生外壳 + 本地逐词阅读内核。安装后无需网络即可打开内置阅读器。

## 当前阶段
- [x] Android 原生 Activity 启动入口
- [x] 原生书架首页首版
- [x] 将原版 HTML 阅读内核打包进 `app/src/main/assets/reader.html`
- [x] WebView 离线加载入口
- [x] GitHub Actions 自动构建 Debug APK
- [ ] 将书架、导入、阅读进度与原内核数据打通
- [ ] Android 文件选择器导入 EPUB/TXT
- [ ] 本地持久化与重启恢复测试
- [ ] 真机布局、字体、音标与 EPUB 图片验收

## 构建
GitHub 仓库推送到 `main`，或在 Actions 手动运行 `Build Android APK`。完成后下载 `zhuci-bookshelf-debug-apk` artifact。

## 注意
这是开发首个可构建阶段，不是已通过真机验收的正式版。原始 HTML 不应在此项目中直接编辑；更新内核时先保留旧版备份。
